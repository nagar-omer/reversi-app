/*****************************************************************************
 * Student Name:    Oved Nagar                                               *
 * Id:              302824875                                                *
 * Student Name:    Orly Paknahad                                            *
 * Id:              315444646                                                *
 * Exercise name:   Ex3                                                      *
 ****************************************************************************/

#include "../include/PlayGround.h"

//TODO remove comment

int main() {
    PlayGround playGround;
    playGround.go();
    return 0;
}
