/*****************************************************************************
 * Student Name:    Oved Nagar                                               *
 * Id:              302824875                                                *
 * Student Name:    Orly Paknahad                                            *
 * Id:              315444646                                                *
 * Exercise name:   Ex3                                                      *
 ****************************************************************************/


#ifndef OTHELLO_GAME_H
#define OTHELLO_GAME_H


class Game {
    virtual void startGame() = 0;
};


#endif //OTHELLO_GAME_H
